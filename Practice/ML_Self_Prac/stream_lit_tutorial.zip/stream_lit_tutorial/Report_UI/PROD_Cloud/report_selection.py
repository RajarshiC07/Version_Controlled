import streamlit as st

print(st.session_state["ENVIRONMENT"])